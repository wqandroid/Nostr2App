package nostr.postr

import org.junit.jupiter.api.Test


internal class ClientTest {
    @Test
    fun getRelays() {
    }

    @Test
    fun getPersonae() {
    }

    @Test
    fun connect() {
    }
}